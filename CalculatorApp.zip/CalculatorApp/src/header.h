#ifndef HEADER_H
#define HEADER_H

#include <iostream>
#include <regex>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

// Base class: EquationSolver
class EquationSolver {
public:
	// Virtual function
	virtual void solve() = 0;

protected:
	// Function to print the solution
	void printSolution(const string& solution) {
		cout << "Solution: " << solution << "\n";
	}
	// Function to handle errors
	void handleError(const string& errorMessage) {
		cerr << "Error: " << errorMessage << "\n";
	}
	// Virtual destructor
	virtual ~EquationSolver() = default;
};

// Derived class: Solve Quadratic Equations
class QuadraticEquationSolver : public EquationSolver {
private:
	double a, b, c;

public:
	// Constructor
	QuadraticEquationSolver(double a, double b, double c) : a(a), b(b), c(c) {}

	// Function to solve the equation
	void solve() override {
		// Check if the coefficient 'a' is zero
		if (a == 0) {
			handleError("Coefficient 'a' cannot be zero in a quadratic equation.");
			return;
		}

		// Calculate the discriminant
		double discriminant = b * b - 4 * a * c;

		// Check the value of the discriminant to determine the type of roots
		// Then print the solution
		if (discriminant > 0) {
			double root1 = (-b + sqrt(discriminant)) / (2 * a);
			double root2 = (-b - sqrt(discriminant)) / (2 * a);
			printSolution("Roots are real and distinct: " + to_string(root1) + ", " + to_string(root2));
		} else if (discriminant == 0) {
			double root = -b / (2 * a);
			printSolution("Roots are real and equal: " + to_string(root));
		} else {
			double realPart = -b / (2 * a);
			double imaginaryPart = sqrt(-discriminant) / (2 * a);
			printSolution("Roots are complex: " + to_string(realPart) + " + " + to_string(imaginaryPart) + "i and " +
						  to_string(realPart) + " - " + to_string(imaginaryPart) + "i");
		}
	}
};

// Derived class: Solve Exponential Equations
class ExponentialEquationSolver : public EquationSolver {
private:
	double a, b, c, d;

public:
	// Constructor
	ExponentialEquationSolver(double a, double b, double c, double d) : a(a), b(b), c(c), d(d) {}

	// Function to solve the equation
	void solve() override {
		// Check if the coefficient 'a' is zero
		if (a == 0) {
			handleError("Coefficient 'a' cannot be zero.");
			return;
		}

		// Solve for x
		double result = (d - c) / a;
		if (result <= 0) {
			handleError("Invalid input: Logarithm of a non-positive number.");
			return;
		}
		double x = log(result) / b;
		printSolution("Exponential equation solution: x = " + to_string(x));
	}
};

// Derived class: Solve Logarithmic Equations
class LogarithmicEquationSolver : public EquationSolver {
private:
	double base, a, c, d;

public:
	// Constructor
	LogarithmicEquationSolver(double base, double a, double c, double d)
		: base(base), a(a), c(c), d(d) {}

	// Function to solve the equation
	void solve() override {
		// Check for invalid input
		if (base <= 0 || base == 1) {
			handleError("Logarithmic base must be positive and not equal to 1.");
			return;
		}
		if (a == 0) {
			handleError("Coefficient 'a' cannot be zero.");
			return;
		}

		// Solve for x and print the solution
		double result = pow(base, d) - c; 
		if (result <= 0) {
			handleError("Invalid input: Logarithm of a non-positive number.");
			return;
		}
		double x = result / a;
		printSolution("Logarithmic equation solution: x = " + to_string(x));
	}
};

// Class to choose the type of equation
class AdvancedCalculator {
public:
	// Constructor to initialize the array of equations
	AdvancedCalculator(const vector<string>& equations) : equations(equations) {}

	// Function to solve all equations in the array
	void solveAllEquations() {
		for (const auto& equation : equations) {
			solveEquation(equation);
		}
	}

private:
	// Array to store multiple equations
	vector<string> equations; 

	// Function to solve a single equation
	void solveEquation(const string& equation) {
		// Remove spaces from the equation
		string eqCopy = equation;
		eqCopy.erase(remove_if(eqCopy.begin(), eqCopy.end(), ::isspace), eqCopy.end());

		// Regular expressions (regex) to match the equation format
		// Example equations for each regex pattern
		// Quadratic equation: 2x^2 + 3x - 5 = 0
		// Exponential equation: 2^(3x) + 4 = 5
		// Logarithmic equation: log_2(3x + 4) = 5
		regex quadraticPattern(R"(([-+]?\d*\.?\d*)\s*\*?\s*x\^2\s*([-+]\s*\d*\.?\d*)\s*\*?\s*x\s*([-+]\s*\d*\.?\d*)\s*=\s*0)");
		regex exponentialPattern(R"(([-+]?\d*\.?\d*)\^\(([-+]?\d*\.?\d*)x\)\s*([-+]?\d*\.?\d*)\s*=\s*([-+]?\d*\.?\d*))");
		regex logarithmicPattern(R"(log_([-+]?\d*\.?\d*)\(\s*([-+]?\d*\.?\d*)x\s*([-+]?\d*\.?\d*)\)\s*=\s*([-+]?\d*\.?\d*))");

		// Variable to store the matches
		smatch match;

		// Check the equation format and create the appropriate solver object
		if (regex_match(eqCopy, match, quadraticPattern)) {
			// Create a QuadraticEquationSolver object and pull the coefficients from the match
			QuadraticEquationSolver solver(stod(match[1].str()), stod(match[2].str()), stod(match[3].str()));
			solver.solve();
		} else if (regex_match(eqCopy, match, exponentialPattern)) {
			// Create an ExponentialEquationSolver object and pull the coefficients from the match
			ExponentialEquationSolver solver(stod(match[1].str()), stod(match[2].str()), stod(match[3].str()), stod(match[4].str()));
			solver.solve();
		} else if (regex_match(eqCopy, match, logarithmicPattern)) {
			// Create a LogarithmicEquationSolver object and pull the coefficients from the match
			LogarithmicEquationSolver solver(stod(match[1].str()), stod(match[2].str()), stod(match[3].str()), stod(match[4].str()));
			solver.solve();
		} else {
			cerr << "Unsupported equation format: " << equation << "\n";
		}
	}
};

#endif // HEADER_H