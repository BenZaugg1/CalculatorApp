#include <iostream>
#include "header.h"
using namespace std;

// Function to display help instructions
void displayHelp() {
    cout << "=== Advanced Calculator Help ===\n";
    cout << "This calculator can solve several different equations.\n";
    cout << "You type an equation into the calculator and then hit enter.\n";
    cout << "You can then type another equation or type 'done' to solve all equations.\n";
    cout << "General rules:\n";
    cout << "- Use 'x' as the variable in the equation.\n";
    cout << "- Do not add spaces\n";
    cout << "\nSupported equations:\n";
    cout << "1. Quadratic: ax^2+bx+c=0 (e.g., 2x^2+3x-5=0)\n";
    cout << "2. Exponential: a^(bx)+c=d (e.g., 2^(3x)+4=5)\n";
    cout << "3. Logarithmic: log_b(ax+c)=d (e.g., log_2(3x+4)=5)\n";
    cout << "   Note: 'log_b' is used to denote a logarithm with base 'b'.\n";
    cout << "\nCommands:\n";
    cout << "- Type 'help' to display this message.\n";
    cout << "- Enter an equation to solve.\n";
    cout << "- Type 'done' to solve all equations entered so far.\n";
    cout << "- Type 'exit' to quit the program.\n";
    cout << "=================================\n";
}

// Main function
int main() {
    vector<string> equations;
    string input;

    // Display welcome message
    cout << "Welcome to the Advanced Calculator!\n";
    cout << "Type 'help' for instructions or enter equations to solve.\n";
    cout << "Type 'done' when you have entered all equations.\n";

    // Main loop to accept user input
    while (true) {
        cout << "\nEnter an equation or command: ";
        // Read user input
        getline(cin, input);

        // Check for commands or equations
        if (input == "help") {
            displayHelp();
            continue;
        } else if (input == "exit") {
            cout << "Exiting the calculator. Goodbye!\n";
            break;
        } else if (input == "done") {
            // Create an instance of the AdvancedCalculator class with the collected equations
            AdvancedCalculator calc(equations);
            calc.solveAllEquations();
            equations.clear(); // Clear the equations vector for new input
        } else {
            equations.push_back(input);
        }
    }
    return 0;
}
